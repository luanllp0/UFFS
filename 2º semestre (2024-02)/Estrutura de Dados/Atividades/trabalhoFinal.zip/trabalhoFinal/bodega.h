#ifndef BODEGA_H
#define BODEGA_H

typedef struct {
    char nome[50];
    char cnpj[20];
} Empresa;

void inicializarEmpresa(Empresa *empresa, char *nome, char *cnpj);

#endif
