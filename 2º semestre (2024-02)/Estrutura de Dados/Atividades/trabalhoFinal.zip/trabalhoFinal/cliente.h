#ifndef CLIENTE_H
#define CLIENTE_H

typedef struct Cliente {
    int codigo;
    char nome[50];
    char cpf[12];
    int idade;
    int fiado; // 1 para sim, 0 para não
    struct Cliente *prox;
} Cliente;

Cliente* criarCliente(int codigo, char *nome, char *cpf, int idade, int fiado);
void cadastrarCliente(Cliente **lista, Cliente *novoCliente);
void mostrarClientes(Cliente *lista);
Cliente* buscarClientePorCPF(Cliente *lista, char *cpf);
void liberarMemoriaClientes(Cliente *lista);

#endif
