#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bebida.h"

Bebida* criarBebida(int codigo, char *nome, int conteudo_ml, float preco_venda, int estoque, int alcoolica, float teor_alcoolico) {
    Bebida *nova = (Bebida *)malloc(sizeof(Bebida));
    nova->codigo = codigo;
    strcpy(nova->nome, nome);
    nova->conteudo_ml = conteudo_ml;
    nova->preco_venda = preco_venda;
    nova->estoque = estoque;
    nova->alcoolica = alcoolica;
    nova->teor_alcoolico = teor_alcoolico;
    nova->prox = NULL;
    return nova;
}

void cadastrarBebida(Bebida **lista, Bebida *novaBebida) {
    if (*lista == NULL) {
        *lista = novaBebida;
        return;
    }
    Bebida *atual = *lista;
    while (atual->prox != NULL) {
        if (atual->codigo == novaBebida->codigo) {
            printf("Código já existe!\n");
            free(novaBebida);
            return;
        }
        atual = atual->prox;
    }
    atual->prox = novaBebida;
}

void mostrarBebidas(Bebida *lista) {
    Bebida *atual = lista;
    while (atual != NULL) {
        printf("Código: %d, Nome: %s, Conteúdo: %dml, Preço: R$%.2f, Estoque: %d\n",
               atual->codigo, atual->nome, atual->conteudo_ml, atual->preco_venda, atual->estoque);
        atual = atual->prox;
    }
}

void comprarBebida(Bebida *lista, int codigo, int quantidade) {
    Bebida *atual = lista;
    while (atual != NULL) {
        if (atual->codigo == codigo) {
            atual->estoque += quantidade;
            printf("Compra realizada. Estoque atualizado.\n");
            return;
        }
        atual = atual->prox;
    }
    printf("Código da bebida não encontrado.\n");
}

int venderBebida(Bebida *lista, int codigo, int quantidade, int idade) {
    Bebida *atual = lista;
    while (atual != NULL) {
        if (atual->codigo == codigo) {
            if (atual->estoque < quantidade) {
                printf("Estoque insuficiente.\n");
                return 0;
            }
            if (atual->alcoolica && idade < 18) {
                printf("Venda proibida para menores de 18 anos.\n");
                return 0;
            }
            atual->estoque -= quantidade;
            return 1;
        }
        atual = atual->prox;
    }
    printf("Código da bebida não encontrado.\n");
    return 0;
}

void liberarMemoriaBebidas(Bebida *lista) {
    Bebida *atual;
    while (lista != NULL) {
        atual = lista;
        lista = lista->prox;
        free(atual);
    }
}
