//mesma coisa que a main acima só q ta com tudo incluso no mesmo arquivo

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    char nome[50];
    char cnpj[20];
} Empresa;

typedef struct Bebida
{
    int codigo;
    char nome[50];
    int conteudo_ml;
    float preco_venda;
    int estoque;
    int alcoolica; // 1 para alcoólica, 0 para não alcoólica
    float teor_alcoolico;
    struct Bebida *prox;
} Bebida;

typedef struct Cliente
{
    int codigo;
    char nome[50];
    char cpf[12];
    int idade;
    int fiado; // 1 para sim, 0 para não
    struct Cliente *prox;
} Cliente;

void inicializarEmpresa(Empresa *empresa, char *nome, char *cnpj)
{
    strcpy(empresa->nome, nome);
    strcpy(empresa->cnpj, cnpj);
}

Bebida *criarBebida(int codigo, char *nome, int conteudo_ml, float preco_venda, int estoque, int alcoolica, float teor_alcoolico)
{
    Bebida *nova = (Bebida *)malloc(sizeof(Bebida));
    nova->codigo = codigo;
    strcpy(nova->nome, nome);
    nova->conteudo_ml = conteudo_ml;
    nova->preco_venda = preco_venda;
    nova->estoque = estoque;
    nova->alcoolica = alcoolica;
    nova->teor_alcoolico = teor_alcoolico;
    nova->prox = NULL;
    return nova;
}

void cadastrarBebida(Bebida **lista, Bebida *novaBebida)
{
    if (*lista == NULL)
    {
        *lista = novaBebida;
        return;
    }
    Bebida *atual = *lista;
    while (atual->prox != NULL)
    {
        if (atual->codigo == novaBebida->codigo)
        {
            printf("Código já existe!\n");
            free(novaBebida);
            return;
        }
        atual = atual->prox;
    }
    atual->prox = novaBebida;
}

void mostrarBebidas(Bebida *lista)
{
    Bebida *atual = lista;
    while (atual != NULL)
    {
        printf("Código: %d, Nome: %s, Conteúdo: %dml, Preço: R$%.2f, Estoque: %d\n",
               atual->codigo, atual->nome, atual->conteudo_ml, atual->preco_venda, atual->estoque);
        atual = atual->prox;
    }
}

void comprarBebida(Bebida *lista, int codigo, int quantidade)
{
    Bebida *atual = lista;
    while (atual != NULL)
    {
        if (atual->codigo == codigo)
        {
            atual->estoque += quantidade;
            printf("Compra realizada. Estoque atualizado.\n");
            return;
        }
        atual = atual->prox;
    }
    printf("Código da bebida não encontrado.\n");
}

int venderBebida(Bebida *lista, int codigo, int quantidade, int idade)
{
    Bebida *atual = lista;
    while (atual != NULL)
    {
        if (atual->codigo == codigo)
        {
            if (atual->estoque < quantidade)
            {
                printf("Estoque insuficiente.\n");
                return 0;
            }
            if (atual->alcoolica && idade < 18)
            {
                printf("Venda proibida para menores de 18 anos.\n");
                return 0;
            }
            atual->estoque -= quantidade;
            return 1;
        }
        atual = atual->prox;
    }
    printf("Código da bebida não encontrado.\n");
    return 0;
}

Cliente *criarCliente(int codigo, char *nome, char *cpf, int idade, int fiado)
{
    Cliente *novo = (Cliente *)malloc(sizeof(Cliente));
    novo->codigo = codigo;
    strcpy(novo->nome, nome);
    strcpy(novo->cpf, cpf);
    novo->idade = idade;
    novo->fiado = fiado;
    novo->prox = NULL;
    return novo;
}

void cadastrarCliente(Cliente **lista, Cliente *novoCliente)
{
    if (*lista == NULL || (*lista)->idade > novoCliente->idade)
    {
        novoCliente->prox = *lista;
        *lista = novoCliente;
        return;
    }
    Cliente *atual = *lista;
    while (atual->prox != NULL && atual->prox->idade <= novoCliente->idade)
    {
        atual = atual->prox;
    }
    novoCliente->prox = atual->prox;
    atual->prox = novoCliente;
}

void mostrarClientes(Cliente *lista)
{
    Cliente *atual = lista;
    while (atual != NULL)
    {
        printf("Código: %d, Nome: %s, CPF: %s, Idade: %d, Fiado: %s\n",
               atual->codigo, atual->nome, atual->cpf, atual->idade,
               atual->fiado ? "Sim" : "Não");
        atual = atual->prox;
    }
}

Cliente *buscarClientePorCPF(Cliente *lista, char *cpf)
{
    while (lista != NULL)
    {
        if (strcmp(lista->cpf, cpf) == 0)
        {
            return lista;
        }
        lista = lista->prox;
    }
    return NULL;
}

// Funções do menu
void menu()
{
    printf("\n--- Sistema da Bodega ---\n");
    printf("1. Cadastrar bebida\n");
    printf("2. Mostrar bebidas\n");
    printf("3. Comprar bebida\n");
    printf("4. Vender bebida\n");
    printf("5. Cadastrar cliente\n");
    printf("6. Mostrar clientes\n");
    printf("7. Sair do sistema\n");
    printf("Escolha uma opção: ");
}

int main()
{
    Empresa bodega;
    inicializarEmpresa(&bodega, "Bodega Seu Maneca", "12.345.678/0001-90");

    Bebida *listaBebidas = NULL;
    Cliente *listaClientes = NULL;

    int opcao, codigo, quantidade, idade, fiado, alcoolico;
    char nome[50], cpf[12];
    float preco, teor;

    while (opcao != 7)
    {
        menu();
        scanf("%d", &opcao);

        switch (opcao)
        {
        case 1:
            printf("Código: ");
            scanf("%d", &codigo);
            printf("Nome: ");
            scanf("%s", nome);
            printf("Conteúdo em ml: ");
            scanf("%d", &quantidade);
            printf("Preço de venda: ");
            scanf("%f", &preco);
            printf("Estoque inicial: ");
            scanf("%d", &quantidade);
            printf("Alcoólica (1-Sim, 0-Não): ");
            scanf("%d", &alcoolico);
            teor = 0;
            if (alcoolico == 1)
            {
                printf("Teor alcoólico: ");
                scanf("%f", &teor);
            }
            cadastrarBebida(&listaBebidas, criarBebida(codigo, nome, quantidade, preco, quantidade, alcoolico, teor));
            break;

        case 2:
            mostrarBebidas(listaBebidas);
            break;

        case 3:
            printf("Código da bebida: ");
            scanf("%d", &codigo);
            printf("Quantidade: ");
            scanf("%d", &quantidade);
            comprarBebida(listaBebidas, codigo, quantidade);
            break;

        case 4:
            printf("CPF do cliente: ");
            scanf("%s", cpf);

            Cliente *clienteEscolhido = buscarClientePorCPF(listaClientes, cpf);
            if (clienteEscolhido == NULL){
                printf("Cliente não encontrado.\n");
                break;
            }

            printf("Código da bebida: ");
            scanf("%d", &codigo);
            printf("Quantidade: ");
            scanf("%d", &quantidade);

            if (venderBebida(listaBebidas, codigo, quantidade, clienteEscolhido->idade))
            {
                printf("Venda realizada com sucesso.\n");
            }
            else
            {
                printf("Erro na venda.\n");
            }
            break;

        case 5:
            printf("Código: ");
            scanf("%d", &codigo);
            printf("Nome: ");
            scanf("%s", nome);
            printf("CPF: ");
            scanf("%s", cpf);
            printf("Idade: ");
            scanf("%d", &idade);
            printf("Pode vender fiado (1-Sim, 0-Não): ");
            scanf("%d", &fiado);
            cadastrarCliente(&listaClientes, criarCliente(codigo, nome, cpf, idade, fiado));
            break;

        case 6:
            mostrarClientes(listaClientes);
            break;

        case 7:
            printf("Sistema encerrado.\n");
            break;

        default:
            printf("Opção inválida.\n");
        }
    }

    return 0;
}