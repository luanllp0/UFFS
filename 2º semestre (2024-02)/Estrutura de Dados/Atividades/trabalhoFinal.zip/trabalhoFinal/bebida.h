#ifndef BEBIDA_H
#define BEBIDA_H

typedef struct Bebida {
    int codigo;
    char nome[50];
    int conteudo_ml;
    float preco_venda;
    int estoque;
    int alcoolica; // 1 para alcoólica, 0 para não alcoólica
    float teor_alcoolico;
    struct Bebida *prox;
} Bebida;

Bebida* criarBebida(int codigo, char *nome, int conteudo_ml, float preco_venda, int estoque, int alcoolica, float teor_alcoolico);
void cadastrarBebida(Bebida **lista, Bebida *novaBebida);
void mostrarBebidas(Bebida *lista);
void comprarBebida(Bebida *lista, int codigo, int quantidade);
int venderBebida(Bebida *lista, int codigo, int quantidade, int idade);
void liberarMemoriaBebidas(Bebida *lista);

#endif
