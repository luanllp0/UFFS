#include <stdio.h>
#include <string.h>
#include "bodega.h"

void inicializarEmpresa(Empresa *empresa, char *nome, char *cnpj) {
    strcpy(empresa->nome, nome);
    strcpy(empresa->cnpj, cnpj);
}
