#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bodega.h"
#include "bebida.h"
#include "cliente.h"

void menu() {
    printf("\n--- Sistema da Bodega ---\n");
    printf("1. Cadastrar bebida\n");
    printf("2. Mostrar bebidas\n");
    printf("3. Comprar bebida\n");
    printf("4. Vender bebida\n");
    printf("5. Cadastrar cliente\n");
    printf("6. Mostrar clientes\n");
    printf("7. Sair do sistema\n");
    printf("Escolha uma opção: ");
}

int main() {
    Empresa bodega;
    inicializarEmpresa(&bodega, "Bodega Seu Maneca", "12.345.678/0001-90");

    Bebida *listaBebidas = NULL;
    Cliente *listaClientes = NULL;

    int opcao, codigo, quantidade_ml, quantidade, idade, fiado, alcoolico;
    char nome[50], cpf[12];
    float preco, teor;

    while (opcao != 7) {
        menu();
        scanf("%d", &opcao);

        switch (opcao) {
        case 1:
            printf("Código: ");
            scanf("%d", &codigo);
            printf("Nome: ");
            scanf("%s", nome);
            printf("Conteúdo em ml: ");
            scanf("%d", &quantidade_ml);
            printf("Preço de venda: ");
            scanf("%f", &preco);
            printf("Estoque inicial: ");
            scanf("%d", &quantidade);
            printf("Alcoólica (1-Sim, 0-Não): ");
            scanf("%d", &alcoolico);
            teor = 0;
            if (alcoolico == 1) {
                printf("Teor alcoólico: ");
                scanf("%f", &teor);
            }
            cadastrarBebida(&listaBebidas, criarBebida(codigo, nome, quantidade_ml, preco, quantidade, alcoolico, teor));
            break;

        case 2:
            mostrarBebidas(listaBebidas);
            break;

        case 3:
            printf("Código da bebida: ");
            scanf("%d", &codigo);
            printf("Quantidade: ");
            scanf("%d", &quantidade);
            comprarBebida(listaBebidas, codigo, quantidade);
            break;

        case 4:
            printf("CPF do cliente: ");
            scanf("%s", cpf);

            Cliente *clienteEscolhido = buscarClientePorCPF(listaClientes, cpf);
            if (clienteEscolhido == NULL) {
                printf("Cliente não encontrado.\n");
                break;
            }

            printf("Código da bebida: ");
            scanf("%d", &codigo);
            printf("Quantidade: ");
            scanf("%d", &quantidade);

            if (venderBebida(listaBebidas, codigo, quantidade, clienteEscolhido->idade)) {
                printf("Venda realizada com sucesso.\n");
            } else {
                printf("Erro na venda.\n");
            }
            break;

        case 5:
            printf("Código: ");
            scanf("%d", &codigo);
            printf("Nome: ");
            scanf("%s", nome);
            printf("CPF: ");
            scanf("%s", cpf);
            printf("Idade: ");
            scanf("%d", &idade);
            printf("Pode vender fiado (1-Sim, 0-Não): ");
            scanf("%d", &fiado);
            cadastrarCliente(&listaClientes, criarCliente(codigo, nome, cpf, idade, fiado));
            break;

        case 6:
            mostrarClientes(listaClientes);
            break;

        case 7:
            liberarMemoriaBebidas(listaBebidas);
            liberarMemoriaClientes(listaClientes);
            printf("Sistema encerrado.\n");
            break;

        default:
            printf("Opção inválida.\n");
        }
    }

    return 0;
}
