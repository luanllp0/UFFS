#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cliente.h"

Cliente* criarCliente(int codigo, char *nome, char *cpf, int idade, int fiado) {
    Cliente *novo = (Cliente *)malloc(sizeof(Cliente));
    novo->codigo = codigo;
    strcpy(novo->nome, nome);
    strcpy(novo->cpf, cpf);
    novo->idade = idade;
    novo->fiado = fiado;
    novo->prox = NULL;
    return novo;
}

void cadastrarCliente(Cliente **lista, Cliente *novoCliente) {
    if (*lista == NULL || (*lista)->idade > novoCliente->idade) {
        novoCliente->prox = *lista;
        *lista = novoCliente;
        return;
    }
    Cliente *atual = *lista;
    while (atual->prox != NULL && atual->prox->idade <= novoCliente->idade) {
        atual = atual->prox;
    }
    novoCliente->prox = atual->prox;
    atual->prox = novoCliente;
}

void mostrarClientes(Cliente *lista) {
    Cliente *atual = lista;
    while (atual != NULL) {
        printf("Código: %d, Nome: %s, CPF: %s, Idade: %d, Fiado: %s\n",
               atual->codigo, atual->nome, atual->cpf, atual->idade,
               atual->fiado ? "Sim" : "Não");
        atual = atual->prox;
    }
}

Cliente* buscarClientePorCPF(Cliente *lista, char *cpf) {
    while (lista != NULL) {
        if (strcmp(lista->cpf, cpf) == 0) {
            return lista;
        }
        lista = lista->prox;
    }
    return NULL;
}

void liberarMemoriaClientes(Cliente *lista) {
    Cliente *atual;
    while (lista != NULL) {
        atual = lista;
        lista = lista->prox;
        free(atual);
    }
}
