import math  # Importa a biblioteca matemática para usar funções como raiz quadrada

# Solicita ao usuário a velocidade da barca e a velocidade do carro
X = float(input("Digite a velocidade em km/h da barca: "))  # Velocidade da barca em km/h
Y = float(input("Digite a velocidade em km/h do carro: "))  # Velocidade do carro em km/h

# Calcula a distância ideal d da estação de barcas até a cidade usando a fórmula derivada
d = (40 * X) / math.sqrt((Y**2) - (X**2))  # A distância d que minimiza o tempo total

# Calcula a distância da barca até a estação usando o teorema de Pitágoras
Db = math.sqrt(40**2 + d**2)  # Distância percorrida pela barca até a costa

# Calcula o tempo que a barca leva para percorrer a distância Db
Tb = Db / X  # Tempo da barca em horas

# Calcula a distância que o carro deve percorrer da estação até a cidade
Dc = 100 - d  # Distância do carro até a cidade

# Calcula o tempo que o carro leva para percorrer a distância Dc
Tc = Dc / Y  # Tempo do carro em horas

# Calcula a distância total percorrida da ilha até a cidade
distancia_total = Db + Dc  # Soma das distâncias percorridas pela barca e pelo carro

# Calcula o tempo total da viagem
tempo_total = Tb + Tc  # Soma dos tempos da barca e do carro

# Exibe a distância da estação até a cidade
print(f"distância da estação até a cidade: {d:.2f}km")  # Distância ideal da estação

# Exibe a distância total percorrida da ilha até a cidade
print(f"distância total percorrida da ilha até a cidade que torna a viagem o mais rápido possível: {distancia_total:.2f} km")  # Distância total
