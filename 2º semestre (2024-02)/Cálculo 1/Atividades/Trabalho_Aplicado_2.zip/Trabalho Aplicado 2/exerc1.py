import math

# Entrada dos dados
V = float(input("Digite a capacidade da lata em cm³: "))
X = float(input("Digite o custo por m² da base: "))
Y = float(input("Digite o custo por m² dos lados: "))

# Conversão de cm³ para m³
V_m3 = V / 1000000

# Cálculo do raio
raio = (V_m3 / (2 * math.pi)) ** (1 / 3)

# Cálculo da altura
altura = V_m3 / (math.pi * raio ** 2)

# Cálculo da área da base e área lateral
area_base = math.pi * raio ** 2
area_lateral = 2 * math.pi * raio * altura

# Cálculo da área total
area_total = area_lateral + 2 * area_base

# Cálculo do custo total
custo_total = (area_lateral * Y) + (2 * area_base * X)

# Resultados
print(f"Raio da base: {raio:.2f} m")
print(f"Altura da lata: {altura:.2f} m")
print(f"Área total da superfície: {area_total:.2f} m²")
print(f"Custo total: R$ {custo_total:.2f}")